
Ce programme a pour but d'analyser un fichier de données (trajet routier). 

AVANT DE LANCER :

IMPORTANT

Insérer le fichier "data.csv" dans le dossier "data".

Pour faire fonctionner le programme tapez : make option="-traitement"

Faites "make help" si besoin ;)

5 traitements :

-d1 : TRAITEMENT [D1] : conducteurs avec le plus de trajets : option -d1
 
-d2 : TRAITEMENT [D2] : conducteurs et la plus grande distance: option -d2

-l : TRAITEMENT [L] : les 10 trajets les plus longs : option -l

-t : TRAITEMENT [T] : les 10 villes les plus traversées : option -t

-s : Traitement [S] : statistiques sur les étapes : option -s
