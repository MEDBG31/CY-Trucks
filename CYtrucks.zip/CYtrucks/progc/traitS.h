#ifndef fonctionsS_h
#define fonctionsS_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

AVL* nvxN_S(int id_trajet, float D);
float moy(AVL* a);
AVL* ajout_id(AVL* a, float D, int id_trajet, int* h);
AVL* nvxNDMm(float min, float max, float moy, int id_trajet);
AVL* ajoutdD(AVL* a, float min, float max, float moy, int id_trajet, int* h);
AVL* copie_trieS(AVL* ancienAVL, AVL** nvxAVL, int* h);
void stockS(AVL* a, char* mode, FILE* fichierSortie, int* compteur);

#endif
