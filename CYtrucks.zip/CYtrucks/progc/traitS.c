#include "AVL.h"
#include "traitS.h"

//Fonction pour créer un nouveau nœud
AVL* nvxN_S(int id_trajet, float D){
    AVL* nvx = (AVL*)malloc(sizeof(AVL));
    if(nvx == NULL){
        exit(1);
    }
    else{
        nvx->id_trajet = id_trajet;
        nvx->D = D;
        nvx->min = D;
        nvx->max = D;
        nvx->moy = D;
        nvx->DMm = 0;
        nvx->comptD = 1;
        //Allouer de la mémoire pour le tableau des distances
        nvx->tab_D = (float*)malloc(sizeof(float));
        if(nvx->tab_D != NULL){
            nvx->tab_D[0] = D;
        }
        else{
            //Gestion de l'erreur d'allocation mémoire
            exit(1);
        }
        nvx->fg = NULL;
        nvx->fd = NULL;
        nvx->eq = 0;
    }
    return nvx;
}

//Fonction qui fait la moyenne des valeurs dans un tableau
float moy(AVL* a){
    if(a == NULL){
        exit(1);
    }
    float res = 0;
    for(int i=0;i<a->comptD;i++){
        res += a->tab_D[i];
    }
    return res/a->comptD;
}

//Fonction pour ajouter un identifiant de trajet dans l'AVL
AVL* ajout_id(AVL* a, float D, int id_trajet, int* h){
    
    //AVL vide donc on crée directement le nœud
    if(a == NULL){
        *h = 1;
        a = nvxN_S(id_trajet, D);
    }
    
    //L'identifiant de trajet a été trouvé dans l'AVL
    if(a->id_trajet == id_trajet){
        *h = 0;
        //Mise à jour du compteur de distance car on va en ajouter une
        a->comptD++;
        //Réallocation du tableau avec une taille augmentée
        float* temp = (float*)realloc(a->tab_D, a->comptD * sizeof(float));
        if(temp != NULL){
            //Ajout de la distance dans le tableau
            a->tab_D = temp;
            a->tab_D[a->comptD - 1] = D;
            //Mise à jour du maximum, du minimum, de la moyenne et de la différence max-min
            float nvxD = D;
            a->min = (nvxD < a->min) ? nvxD : a->min;
            a->max = (nvxD > a->max) ? nvxD : a->max;
            a->moy = moy(a);
            a->DMm = a->max - a->min;
        }
        else{
            //Gestion de l'erreur d'allocation mémoire
            exit(1);
        }
    }
    
    //Ajout de l'identifiant de trajet dans le sous arbre de gauche
    else if(id_trajet<a->id_trajet){
        a->fg = ajout_id(a->fg,D,id_trajet,h);
        *h = -*h;
    }
    
    //Ajout de l'identifiant de trajet dans le sous arbre de droite
    else{
        a->fd = ajout_id(a->fd,D,id_trajet,h);
    }
    
    //Equilibre de l'AVL
    if(*h != 0){
        a->eq = a->eq + *h;
        a=eqAVL(a);
        if(a->eq == 0){
            *h = 0;
        }
        else{
            *h = 1;
        }
    }
    return a;
}

//Fonction pour créer un nouveau nœud 
AVL* nvxNDMm(float min, float max, float moy, int id_trajet){
    AVL* nvx = (AVL*)malloc(sizeof(AVL));
    if(nvx == NULL){
        exit(1);
    }
    else{
        nvx->min = min;
        nvx->max = max;
        nvx->moy = moy;
        nvx->DMm = max - min;
        nvx->id_trajet = id_trajet;
        nvx->fg = NULL;
        nvx->fd = NULL;
        nvx->eq = 0;
    }
    return nvx;
}

//Fonction pour ajouter une nouvelle différence de distance dans l'AVL
AVL* ajoutdD(AVL* a, float min, float max, float moy, int id_trajet, int* h){
    float DMm=max-min;
    
    //AVL vide donc on crée directement le nœud
    if(a == NULL){
        *h = 1;
        a = nvxNDMm(min,max,moy,id_trajet);
    }
    
    //Ajout de la différence dans le sous arbre de gauche
    if(a->DMm>DMm){
        a->fg = ajoutdD(a->fg,min,max,moy,id_trajet,h);
        *h = -*h;
    }
    
    //Ajout de la différence dans le sous arbre de droite
    else if(a->DMm<DMm){
        a->fd = ajoutdD(a->fd,min,max,moy,id_trajet,h);
    }
    
    //La différence existe déjà donc on trie par identifiant de trajet
    else{
        
        //Ajout de la différence dans le sous arbre de gauche
        if(a->id_trajet>id_trajet){
            a->fg = ajoutdD(a->fg,min,max,moy,id_trajet,h);
            *h = -*h;
        }
        
        //Ajout de la différence dans le sous arbre de droite
        else if(a->id_trajet<id_trajet){
            a->fd = ajoutdD(a->fd,min,max,moy,id_trajet,h);
        }
        
        else{
            *h = 0;
            return a;
        }
    }
    
    //Equilibre de l'AVL
    if(*h != 0){
        a->eq = a->eq + *h;
        a=eqAVL(a);
        if(a->eq == 0){
            *h = 0;
        }
        else{
            *h = 1;
        }
    }
    return a;
}

//Fonction pour copier les données du premier AVL dans un second et faire un nouveau tri
AVL* copie_trieS(AVL* ancienAVL, AVL** nouvelAVL, int* h){
    if(ancienAVL != NULL){
        *nouvelAVL = ajoutdD(*nouvelAVL, ancienAVL->min, ancienAVL->max, ancienAVL->moy, ancienAVL->id_trajet, h);
        //Appeler récursivement les sous-arbres
        if(ancienAVL->fg != NULL){
            copie_trieS(ancienAVL->fg, nouvelAVL, h);
        }
        if(ancienAVL->fd != NULL){
            copie_trieS(ancienAVL->fd, nouvelAVL, h);
        }
    }
    return *nouvelAVL;
}

//Fonction pour stocker dans le fichier de sortie les 50 plus grandes différences de distances max-min
void stockS(AVL* a, char* mode, FILE* fichierSortie, int* compteur) {
    if(a != NULL && *compteur < 50){
        stockS(a->fd, mode, fichierSortie, compteur);
        if (*compteur >= 50) {
            return;
        }
        fprintf(fichierSortie, "%d;%d;%.3f;%.3f;%.3f;%.3f\n", *compteur+1, a->id_trajet, a->min, a->max, a->moy, a->DMm);
        (*compteur)++;
        stockS(a->fg, mode, fichierSortie, compteur);
    }
}
