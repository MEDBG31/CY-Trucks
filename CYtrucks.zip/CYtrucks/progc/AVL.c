#include "AVL.h"

//Fonction qui donne le maximum entre deux entiers
int max(int a,int b){
    if(a>b){
        return a;
    }
    else{
        return b;
    }
}

//Fonction qui donne le minimum entre deux entiers
int min(int a,int b){
    if(a>b){
        return b;
    }
    else{
        return a;
    }
}

//Fonction qui fait une rotation vers la gauche
AVL* rG(AVL* a){ //rG = Rotation Gauche
    if(a==NULL){
        exit(1);
    }
    AVL* pivot;
    int eq_a,eq_p;
    pivot=a->fd;
    a->fd=pivot->fg;
    pivot->fg=a;
    eq_a=a->eq;
    eq_p=pivot->eq;
    a->eq=eq_a-max(eq_p,0)-1;
    pivot->eq=min(min(eq_a-2,eq_a+eq_p-2),eq_p-1);
    a=pivot;
    return a;
}

//Fonction qui fait une rotation vers la droite
AVL* rD(AVL* a){
    if(a==NULL){
        exit(1);
    }
    AVL* pivot;
    int eq_a,eq_p;
    pivot=a->fg;
    a->fg=pivot->fd;
    pivot->fd=a;
    eq_a=a->eq;
    eq_p=pivot->eq;
    a->eq=eq_a-min(eq_p,0)+1;
    pivot->eq=max(max(eq_a+2,eq_a+eq_p+2),eq_p+1);
    a=pivot;
    return a;
}

//Fonction qui fait une double rotation vers la gauche
AVL* drG(AVL* a){ 
    if(a==NULL){
        exit(1);
    }
    a->fd=rD(a->fd);
    return rG(a);
}

//Fonction qui fait une double rotation vers la droite
AVL* drD(AVL* a){ 
    if(a==NULL){
        exit(1);
    }
    a->fg=rG(a->fg);
    return rD(a);
}

//Fonction qui equilibre l'AVL en fonction du facteur d'équilibre du noeud
AVL* eqAVL(AVL* a){ 
    if(a==NULL){
        exit(1);
    }
    if(a->eq>=2){
        if(a->fd->eq>=0){
            return rG(a);
        }
        else{
            return drG(a);
        }
    }
    else if(a->eq<=-2){
        if(a->fg->eq<=0){
            return rD(a);
        }
        else{
            return drD(a);
        }
    }
    return a;
}

//Fonction qui libère la mémoire de l'AVL
void lbMem(AVL* a){ 
    if(a!=NULL){
        lbMem(a->fg);
        lbMem(a->fd);
        free(a);
    }
}
