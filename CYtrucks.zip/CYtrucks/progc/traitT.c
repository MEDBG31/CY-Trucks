#include "AVL.h"
#include "traitT.h"

//Fonction pour créer un nouveau nœud
AVL* nvxN_T(int id_trajet, int id_etape, char ville[], char type[]){
    AVL* nvx = (AVL*)malloc(sizeof(AVL));
    if(nvx == NULL){
        exit(1);
    }
    else{
        nvx->id_trajet = id_trajet;
        nvx->id_etape = id_etape;
        strcpy(nvx->ville, ville);
        nvx->comptT = 0;
        nvx->comptdepart = 0;
        //Si c'est la première étape d'un trajet on augmente le compteur
        if(strcmp(type,"depart")==0 && id_etape==1){
            nvx->comptdepart++;
        }
        //Allouer de la mémoire pour le tableau d'identifiants de trajets
        nvx->tab_id = (int*)malloc(sizeof(int));
        if(nvx->tab_id != NULL){
            nvx->tab_id[0] = id_trajet;
        }
        else{
            //Gestion de l'erreur d'allocation mémoire
            exit(1);
        }
        nvx->fg = NULL;
        nvx->fd = NULL;
        nvx->eq = 0;
    }
    return nvx;
}

//Fonction pour ajouter une ville dans l'AVL
AVL* ajoutville(AVL* a, char ville[], int id_trajet, int id_etape, char type[], int* h){
    
    //AVL vide donc on crée directement le nœud
    if(a == NULL){
        *h = 1;
        a = nvxN_T(id_trajet, id_etape, ville, type);
    }
    
    //Comparaison entre la ville de l'AVL et la ville passée en paramètre
    int compare=strcmp(ville, a->ville);
    //Si c'est la même ville
    if(compare == 0){
        *h = 0;
        int i=0;
        
        //On regarde si l'identifiant est déjà présent
        while(a->tab_id[i] != 0){
            //Ville et identifiant déjà présents
            if(id_trajet == a->tab_id[i]){
                //Si c'est la première étape d'un trajet on augmente le compteur
                if(strcmp(type,"depart") == 0 && id_etape == 1){
                    a->comptdepart++;
                }
                return a;
            }
            i++;
        }
        
        //Ville déjà présente donc on met à jour le compteur total et le tableau comptenant les identifiants
        a->comptT++;
         //Si c'est la première étape d'un trajet on augmente le compteur
        if(strcmp(type,"depart") == 0 && id_etape == 1){
            a->comptdepart++;
        }
        //Réallocation du tableau avec une taille augmentée
        int* temp = (int*)realloc(a->tab_id, a->comptT * sizeof(int));
        if(temp != NULL){
            //Ajout de l'identifiant de trajet dans le tableau
            a->tab_id = temp;
            a->tab_id[a->comptT - 1] = id_trajet;
        }
        else{
            //Gestion de l'erreur d'allocation mémoire
            exit(1);
        }
    }
    
    //Ajout de la ville dans le sous arbre de gauche
    else if(compare < 0){
        a->fg = ajoutville(a->fg, ville, id_trajet, id_etape, type, h);
        *h = -*h;
    }
    
    //Ajout de la ville dans le sous arbre de droite
    else{
        a->fd = ajoutville(a->fd, ville, id_trajet, id_etape, type, h);
    }
    
    //Equilibre de l'AVL
    if(*h != 0){
        a->eq = a->eq + *h;
        a=eqAVL(a);
        if(a->eq == 0){
            *h = 0;
        }
        else{
            *h = 1;
        }
    }
    return a;
}

//Fonction pour créer un nouveau nœud
AVL* nvxNVcompt(char ville[], int comptT, int comptdepart){
    AVL* nvx = (AVL*)malloc(sizeof(AVL));
    if(nvx == NULL){
        exit(1);
    }
    else{
        strcpy(nvx->ville, ville);
        nvx->comptT = comptT;
        nvx->comptdepart = comptdepart;
        nvx->fg = NULL;
        nvx->fd = NULL;
        nvx->eq = 0;
    }
    return nvx;
}

//Fonction pour ajouter un nouveau compteur dans l'AVL
AVL* ajoutcompt(AVL* a, char ville[], int comptT, int comptdepart, int* h){
    
    //AVL vide donc on crée directement le nœud
    if(a == NULL){
        *h = 1;
        a = nvxNVcompt(ville,comptT,comptdepart);
    }
    
    //Ajout du compteur dans le sous arbre de gauche
    if(a->comptT>comptT){
        a->fg = ajoutcompt(a->fg,ville,comptT,comptdepart,h);
        *h = -*h;
    }
    
    //Ajout du compteur dans le sous arbre de droite
    else if(a->comptT<comptT){
        a->fd = ajoutcompt(a->fd,ville,comptT,comptdepart,h);
    }
    
    //Le compteur existe déjà donc on trie par ville
    else{
        
        //Ajout du compteur dans le sous arbre de gauche
        if(strcmp(ville,a->ville)<0){
            a->fg = ajoutcompt(a->fg,ville,comptT,comptdepart,h);
            *h = -*h;
        }
        
        //Ajout du compteur dans le sous arbre de droite
        else if(strcmp(ville,a->ville)>0){
            a->fd = ajoutcompt(a->fd,ville,comptT,comptdepart,h);
        }
        
        else{
            *h = 0;
            return a;
        }
    }
    
    //Equilibre de l'AVL
    if(*h != 0){
        a->eq = a->eq + *h;
        a=eqAVL(a);
        if(a->eq == 0){
            *h = 0;
        }
        else{
            *h = 1;
        }
    }
    return a;
}

//Fonction pour copier les données du premier AVL dans un second et faire un nouveau tri
AVL* copie_trieT(AVL* ancienAVL, AVL** nouvelAVL, int* h){
    if(ancienAVL != NULL){
        //Copier les données dans le nouvel AVL
        *nouvelAVL = ajoutcompt(*nouvelAVL, ancienAVL->ville, ancienAVL->comptT, ancienAVL->comptdepart, h);
        //Appeler récursivement les sous-arbres
        if(ancienAVL->fg != NULL){
            copie_trieT(ancienAVL->fg, nouvelAVL, h);
        }
        if(ancienAVL->fd != NULL){
            copie_trieT(ancienAVL->fd, nouvelAVL, h);
        }
    }
    return *nouvelAVL;
}

//Fonction pour comparer deux chaînes de caractères
int compareville(const void* a, const void* b){
    AVL* villeA = *((AVL**)a);
    AVL* villeB = *((AVL**)b);
    return strcmp(villeA->ville, villeB->ville);
}

// Fonction pour stocker dans le fichier de sortie les 10 villes qui ont le plus de trajets
void stockT(AVL* a, char* mode, FILE* fichierSortie, int* compteur, AVL** tab_id){
    if(a != NULL && *compteur < 10){
        stockT(a->fd, mode, fichierSortie, compteur, tab_id);
        if(*compteur >= 10){
            return;
        }
        //Stocker la ville dans le tableau
        tab_id[*compteur] = a;
        (*compteur)++;
        stockT(a->fg, mode, fichierSortie, compteur, tab_id);
    }
}

//Fonction qui trie les données du fichier de sortie dans l'ordre alphabétique
void trialphabe(AVL* a, char* mode, FILE* fichierSortie){
    if(a == NULL){
        exit(1);
    }
    int compteur = 0;  // Initialiser le compteur
    AVL* tab_id[10];  // Tableau pour stocker les 10 villes
    stockT(a, mode, fichierSortie, &compteur, tab_id);
    //Trier le tableau par ordre alphabétique
    qsort(tab_id, compteur, sizeof(AVL*), compareville);
    //Écrire les données triées dans le fichier de sortie
    for (int i = 0; i < compteur; i++) {
        fprintf(fichierSortie, "%s;%d;%d\n", tab_id[i]->ville, tab_id[i]->comptT, tab_id[i]->comptdepart);
    }
}
