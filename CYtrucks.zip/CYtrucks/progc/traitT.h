#ifndef fonctionsT_h
#define fonctionsT_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

AVL* nvxN(int id_trajet, int id_etape, char ville[], char type[]);
AVL* ajoutville(AVL* a, char ville[], int id_trajet, int id_etape, char type[], int* h);
AVL* nvxNVcompt(char ville[], int comptT, int comptdepart);
AVL* ajoutcompt(AVL* a, char ville[], int comptT, int comptdepart, int* h);
AVL* copie_trieT(AVL* ancienAVL, AVL** nouvelAVL, int* h);
int compareville(const void* a, const void* b);
void stockT(AVL* a, char* mode, FILE* fichierSortie, int* compteur, AVL** tab_id);
void trialphabe(AVL* a, char* mode, FILE* fichierSortie);

#endif
